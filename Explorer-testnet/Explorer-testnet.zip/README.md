# Sirious Blockchain Explorer

This Blockchain Explorer is entirely self contained.

Just drop the files in a publicly accessible web folder and you've got your own copy of the explorer.

###### Forked from TurtlePay's® Explorer
